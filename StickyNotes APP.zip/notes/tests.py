# Create your tests here.
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from .models import StickyNote, Category
from .forms import StickyNoteForm

# Get the active User model (essential for testing)
User = get_user_model()


class StickyNoteTest(TestCase):
    """
    Tests for StickyNote CRUD operations, requiring a logged-in user.
    """

    def setUp(self):
        # 1. Create two users for isolation testing
        self.user1 = User.objects.create_user(username="user1", password="password123")
        self.user2 = User.objects.create_user(username="user2", password="password123")

        # 2. Create categories for both users
        self.cat1 = Category.objects.create(
            name="Personal", color="#FFFFFF", user=self.user1
        )
        self.cat2 = Category.objects.create(
            name="Work", color="#000000", user=self.user2
        )

        # 3. Create a note owned by user1
        self.note1 = StickyNote.objects.create(
            user=self.user1,
            title="Test Note 1",
            content="Content for note 1.",
            category=self.cat1,
        )

        # 4. Initialize a test client and log in user1
        self.client = Client()
        self.client.login(username="user1", password="password123")

    # --- R (Retrieve) Tests ---

    def test_view_sticky_notes_success(self):
        """Test that the notes list view loads and shows only user1's note."""
        response = self.client.get(reverse("view_sticky_notes"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Note 1")  # Should see user1's note
        self.assertQuerySetEqual(
            response.context["sticky_notes"],
            [self.note1],
            transform=lambda x: x,  # Check that only one note (note1) is returned
        )

    def test_view_sticky_notes_requires_login(self):
        """Test that unauthenticated access redirects to login."""
        self.client.logout()  # Log out the client
        response = self.client.get(reverse("view_sticky_notes"))
        self.assertEqual(response.status_code, 302)  # Should redirect

    # --- C (Create) Tests ---

    def test_create_sticky_note_get_success(self):
        """Test that the creation page loads successfully."""
        response = self.client.get(reverse("create_sticky_note"))
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.context["form"], StickyNoteForm)

    def test_create_sticky_note_post_success(self):
        """Test successful note creation and user assignment."""
        note_count = StickyNote.objects.count()
        new_note_data = {
            "title": "New Note from Test",
            "content": "New content.",
            "category": self.cat1.id,  # Use user1's category
        }
        response = self.client.post(
            reverse("create_sticky_note"), new_note_data, follow=True
        )

        self.assertEqual(
            response.status_code, 200
        )  # Followed redirect (view_sticky_notes)
        self.assertEqual(
            StickyNote.objects.count(), note_count + 1
        )  # Note count increased

        # Verify the new note belongs to user1
        new_note = StickyNote.objects.get(title="New Note from Test")
        self.assertEqual(new_note.user, self.user1)
        self.assertRedirects(response, reverse("view_sticky_notes"))

    # --- U (Update) Tests ---

    def test_edit_sticky_note_post_success(self):
        """Test successful update of user1's note."""
        new_title = "Updated Title"
        response = self.client.post(
            reverse("edit_sticky_note", args=[self.note1.id]),
            {
                "title": new_title,
                "content": self.note1.content,
                "category": self.cat1.id,
            },
            follow=True,
        )
        self.note1.refresh_from_db()
        self.assertEqual(self.note1.title, new_title)
        self.assertRedirects(response, reverse("view_sticky_notes"))

    def test_edit_sticky_note_post_unauthorized(self):
        """Test that user1 cannot edit user2's note (should 404)."""
        # Create a note for user2
        note2 = StickyNote.objects.create(
            user=self.user2, title="User2 Note", content="Private", category=self.cat2
        )

        # user1 attempts to edit note2
        response = self.client.post(
            reverse("edit_sticky_note", args=[note2.id]),
            {
                "title": "Hacked Title",
                "content": "Hacked Content",
                "category": self.cat2.id,
            },
            follow=True,
        )
        # Should return 404 because get_object_or_404 filters by user=request.user
        self.assertEqual(response.status_code, 404)

    # --- D (Delete) Tests ---

    def test_delete_sticky_note_post_success(self):
        """Test successful deletion of user1's note."""
        note_count = StickyNote.objects.count()
        response = self.client.post(
            reverse("delete_sticky_note", args=[self.note1.id]), follow=True
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(StickyNote.objects.count(), note_count - 1)
        self.assertFalse(StickyNote.objects.filter(id=self.note1.id).exists())
        self.assertRedirects(response, reverse("view_sticky_notes"))

    def test_delete_sticky_note_post_unauthorized(self):
        """Test that user1 cannot delete user2's note (should 404)."""
        # Create a note for user2
        note2 = StickyNote.objects.create(
            user=self.user2, title="User2 Note", content="Private", category=self.cat2
        )
        initial_count = StickyNote.objects.count()

        # user1 attempts to delete note2
        response = self.client.post(
            reverse("delete_sticky_note", args=[note2.id]), follow=True
        )

        # Should return 404 because get_object_or_404 filters by user=request.user
        self.assertEqual(response.status_code, 404)
        self.assertEqual(
            StickyNote.objects.count(), initial_count
        )  # No deletion occurred

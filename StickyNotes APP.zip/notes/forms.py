# notes/forms.py - CLEANED UP VERSION

from django import forms
from .models import StickyNote, Category


class StickyNoteForm(forms.ModelForm):
    # This form is perfect for Create and Edit views (as seen in views.py)
    class Meta:
        model = StickyNote
        fields = ['title', 'content', 'category']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Title'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Content'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
        }

    # Custom field validation methods are fine, but can often be removed
    # if the model fields are already defined as non-blank.
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if not title:
            # Note: This is usually redundant if the model field has blank=False
            raise forms.ValidationError("Title cannot be empty.")
        return title
    
    def clean_content(self):
        content = self.cleaned_data.get('content')
        if not content:
            # Note: This is usually redundant if the model field has blank=False
            raise forms.ValidationError("Content cannot be empty.")
        return content


class CategoryForm(forms.ModelForm):
    # This form is perfect for the Manage Categories view
    class Meta:
        model = Category
        fields = ['name', 'color']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Category Name'}),
            'color': forms.TextInput(attrs={'class': 'form-control', 'type': 'color'}),
        }

    # Custom validation logic for name uniqueness and hex color format is excellent!
    def clean_name(self):
        name = self.cleaned_data.get('name')
        # Check if the name already exists, excluding the current instance if editing
        if self.instance.pk is None and Category.objects.filter(name=name).exists():
            raise forms.ValidationError("Category with this name already exists.")
        return name
    
    def clean_color(self):
        color = self.cleaned_data.get('color')
        # Simple hex validation
        if not color.startswith('#') or len(color) != 7:
            raise forms.ValidationError("Enter a valid hex color code (e.g., #RRGGBB).")
        return color

# notes/forms.py - CLEANED UP VERSION

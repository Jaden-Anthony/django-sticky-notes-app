from django.urls import path
from .views import (
    create_sticky_note,
    view_sticky_notes,
    edit_sticky_note,
    delete_sticky_note,
    manage_categories,
    register,
)

# notes/urls.py - **CORRECTED PATHS**
urlpatterns = [
    path('create/', create_sticky_note, name='create_sticky_note'),  # URL: notes/create/
    path('', view_sticky_notes, name='view_sticky_notes'),           # URL: notes/
    path('edit/<int:note_id>/', edit_sticky_note, name='edit_sticky_note'),
    path('delete/<int:note_id>/', delete_sticky_note, name='delete_sticky_note'),
    path('categories/manage/', manage_categories, name='manage_categories'),
    path('register/', register, name='register'),
]

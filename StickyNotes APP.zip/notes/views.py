from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import StickyNote, Category
from .forms import StickyNoteForm, CategoryForm
from django.contrib.auth.forms import UserCreationForm


@login_required
def view_sticky_notes(request):
    """Retrieves and displays sticky notes owned by the logged-in user."""
    context = {
        "sticky_notes": StickyNote.objects.filter(user=request.user).order_by(
            "-updated_at"
        ),
        "page_title": "View Sticky Notes",
    }
    return render(request, "notes/view_sticky_notes.html", context)


@login_required
def create_sticky_note(request):
    """Handles displaying the empty form (GET) and saving a new note (POST)."""
    if request.method == "POST":
        form = StickyNoteForm(request.POST)
        if form.is_valid():
            # ACTIVATED: Assign the current user to the note before saving
            note = form.save(commit=False)
            note.user = request.user
            note.save()
            return redirect("view_sticky_notes")
    else:
        form = StickyNoteForm()

    context = {
        "form": form,
        "page_title": "Create Sticky Note",
    }
    return render(request, "notes/create_sticky_note.html", context)


@login_required
def edit_sticky_note(request, note_id):
    """Handles displaying the existing form (GET) and updating a note (POST)."""
    # Filters by user to prevent editing of other users' notes
    note = get_object_or_404(StickyNote, pk=note_id, user=request.user)

    if request.method == "POST":
        form = StickyNoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect("view_sticky_notes")
    else:
        form = StickyNoteForm(instance=note)

    context = {
        "form": form,
        "note": note,
        "page_title": "Edit Sticky Note",
    }
    return render(request, "notes/edit_sticky_note.html", context)


@login_required
def delete_sticky_note(request, note_id):
    """Handles displaying the confirmation page (GET) and deleting the note (POST)."""
    # Filters by user to prevent deleting of other users' notes
    note = get_object_or_404(StickyNote, pk=note_id, user=request.user)

    if request.method == "POST":
        note.delete()
        return redirect("view_sticky_notes")

    context = {
        "note": note,
        "page_title": "Delete Sticky Note",
    }
    return render(request, "notes/delete_sticky_note.html", context)


@login_required
def manage_categories(request):
    """Handles category management."""
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            # ACTIVATED: Assign the current user to the category
            category = form.save(commit=False)
            category.user = request.user
            category.save()
            return redirect("manage_categories")
    else:
        form = CategoryForm()

    context = {
        # CRITICAL FIX: Only retrieve categories belonging to the current user
        'categories': Category.objects.filter(user=request.user).order_by('name'),
        'form': form,
        "page_title": "Manage Categories",
    }
    return render(request, "notes/manage_categories.html", context)


def register(request):
    """Handles new user registration."""
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            # Simply save the user instance created by the form
            form.save()
            # Redirect to the login page after successful registration
            return redirect("/accounts/login/")
    else:
        form = UserCreationForm()

    context = {"form": form, "page_title": "Register New Account"}
    return render(request, "notes/register.html", context)
